﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadData();
            listView1.MouseClick += ListView_MouseClick;

        }

        private void LoadData()
        {
            listView1.Items.Clear();
            ImageList imageList = new ImageList();

            imageList.ImageSize = new Size(50, 50);

            imageList.Images.Add(new Bitmap("cat.jpg"));
            imageList.Images.Add(new Bitmap("cat.jpg"));

            Bitmap emptyImage = new Bitmap(30, 30);

            using (Graphics gr = Graphics.FromImage(emptyImage))
            {
                gr.Clear(Color.White);
            }
            imageList.Images.Add(emptyImage);

            listView1.SmallImageList = imageList;

            string[] firstName = { "Кот", "Мяу", "Кити" };
            string[] lastName = { "Котович", "Мяуч", "Кэт" };

            for (int i = 0; i < firstName.Length; i++)
            {
                ListViewItem listViewItem = new ListViewItem(new string[] { "", firstName[i], lastName[i] });

                listViewItem.ImageIndex = i;

                listView1.Items.Add(listViewItem);
            }
        }
        private void ListView_MouseClick(object sender, MouseEventArgs e)
        {
            ListViewItem item = listView1.GetItemAt(e.X, e.Y);
            if (item != null && MessageBox.Show("Вы уверены, что хотите удалить этот элемент?", "Подтверждение удаления", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                listView1.Items.Remove(item);
            }
        }
    }
}
