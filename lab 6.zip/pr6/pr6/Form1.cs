﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitiaLizeListView();
        }

        private void InitiaLizeListView()
        {
            listView1.View = View.Details;
            listView1.Columns.Add("Имя", 100);
            listView1.Columns.Add("Должность", 100);
            listView1.Columns.Add("Статус", 100);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string[] row = new string[]
            {
                textBoxName.Text,
                textBoxPosition.Text,
                textBoxStatus.Text
            };
            ListViewItem item = new ListViewItem(row);
            listView1.Items.Add(item);

            ClearInputFields();

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = listView1.SelectedItems[0];
                selectedItem.SubItems[0].Text = textBoxName.Text;
                selectedItem.SubItems[1].Text = textBoxPosition.Text;
                selectedItem.SubItems[2].Text = textBoxStatus.Text;

                ClearInputFields();
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите сотрудника для редактирования.");

            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                listView1.Items.Remove(listView1.SelectedItems[0]);
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите сотрудника для удаления");
            }
        }

        private void ListView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count > 0)
            {
                ListViewItem selectedItem = listView1.SelectedItems[0];
                textBoxName.Text = selectedItem.SubItems[0].Text;
                textBoxPosition.Text = selectedItem.SubItems[1].Text;
                textBoxStatus.Text = selectedItem.SubItems[2].Text;
            }

        }

        private void ClearInputFields ()
        {
            textBoxName.Clear();
            textBoxPosition.Clear();
            textBoxStatus.Clear();
        }
    }
}
